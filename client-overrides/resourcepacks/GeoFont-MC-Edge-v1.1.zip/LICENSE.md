## License

This resourcepack is under the [Attribution-NonCommercial-ShareAlike 4.0 International](https://creativecommons.org/licenses/by-nc-sa/4.0/) license.

GeoFont (typeface) is licensed under [SIL Open Font License 1.1](https://github.com/Xetheon/GeoFont/blob/main/LICENSE)

You can use these assets in your own resourcepacks or other projects as long as it's not for-profit, and you give proper credit. This does NOT apply to the font itself, but crediting when using it is still encouraged.

For crediting, you can use this link: https://gist.github.com/Xetheon/c3d677e0762658f8d79cf05e2c6e65ff
